﻿Public Class Kamar

    Public Property id_kamar As String
    Public Property nama_kamar As String
    Public Property jenis_kamar As String
    Public Property harga As String

End Class